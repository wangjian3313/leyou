create view cid3 as
select `heima`.`tb_category`.`parent_id` AS `parent_id`
from `heima`.`tb_category`
group by `heima`.`tb_category`.`parent_id`;

